<html>
	<head>
		<meta charset="UTF-8">
	<head/>
<body bgcolor="0,255,255">
  <h1 align="center">CALCULADORA</h1>

  <form name="form1" method=get action="processa.php" align="center"  >  
  Número 1:<input type=text name="numero1">
<br/><br/>
  Número 2:<input type=text name="numero2">
  <br/>
  <br/>

<input type="submit"  name="operacao" value="somar">
<input type="submit"  name="operacao" value="subtrair">
<input type="submit"  name="operacao" value="dividir">
<input type="submit"  name="operacao" value="multiplicar">
<form/>
<body/>



<html/>
