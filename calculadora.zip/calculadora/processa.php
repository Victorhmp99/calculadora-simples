<?php

   $a = $_GET["numero1"];
   $b = $_GET["numero2"];
   $op= $_GET["operacao"];

   if( !empty($op) ) {
      if($op == "somar")
         $c = $a + $b;
      else if($op == "subtrair")
         $c = $a - $b;
      else if($op == "multiplicar")
         $c = $a*$b;
      else
         $c = $a/$b;

      echo "O RESULTADO DA OPERAÇÃO: $c";
   }

?>       